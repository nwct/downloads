function openssHint(itemNum){
    statusmenu = "";
    width="350px";

    if(itemNum == 0){
        statusmenu ="如果发现开关不能开启，那么请检查<a href='Advanced_System_Content.asp'><u><font color='#00F'>系统管理 -- 系统设置</font></u></a>页面内Enable JFFS custom scripts and configs是否开启。";
        _caption = "服务器说明";
    }
    else if(itemNum == 1){
        statusmenu ="此处填入你的nps服务器地址，可使用域名，也可使用IP地址<br/>";
        _caption = "nps服务器";
    }
    else if(itemNum == 2){
        statusmenu ="此处填入你的nps服务器的桥接端口";
        _caption = "桥接端口";
    }
    else if(itemNum == 3){
        statusmenu ="此处填入你的nps服务器分配的vkey。<br/><font color='#F46'>注意：</font>必须正确填写，否则将无法连接服务器。";
        _caption = "vkey";
    }
    
        return overlib(statusmenu, OFFSETX, -160, LEFT, STICKY, WIDTH, 'width', CAPTION, _caption, CLOSETITLE, '');

    var tag_name= document.getElementsByTagName('a');
    for (var i=0;i<tag_name.length;i++)
        tag_name[i].onmouseout=nd;

    if(helpcontent == [] || helpcontent == "" || hint_array_id > helpcontent.length)
        return overlib('<#defaultHint#>', HAUTO, VAUTO);
    else if(hint_array_id == 0 && hint_show_id > 21 && hint_show_id < 24)
        return overlib(helpcontent[hint_array_id][hint_show_id], FIXX, 270, FIXY, 30);
    else{
        if(hint_show_id > helpcontent[hint_array_id].length)
            return overlib('<#defaultHint#>', HAUTO, VAUTO);
        else
            return overlib(helpcontent[hint_array_id][hint_show_id], HAUTO, VAUTO);
    }
}
