#!/bin/sh

MODULE="npc"
VERSION="2019.08.19"
client_version=""
cd /
rm -f /jffs/.koolshare/init.d/S97${MODULE}.sh
[ ! -d /jffs/.koolshare/res/layer ] && ( mkdir -p /jffs/.koolshare/res/layer/; cp -rf /tmp/npc/res/layer/* /jffs/.koolshare/res/layer/ )
#cp -f /tmp/$MODULE/bin/* /jffs/.koolshare/bin/
cp -f /tmp/$MODULE/scripts/* /jffs/.koolshare/scripts/
cp -f /tmp/$MODULE/res/* /jffs/.koolshare/res/
cp -f /tmp/$MODULE/webs/* /jffs/.koolshare/webs/
cp -f /tmp/$MODULE/init.d/* /jffs/.koolshare/init.d/
rm -rf /tmp/npc* >/dev/null 2>&1
killall ${MODULE}_protect.sh || true >/dev/null 2>&1
killall ${MODULE} || true >/dev/null 2>&1
chmod +x /jffs/.koolshare/bin/${MODULE}
chmod +x /jffs/.koolshare/scripts/${MODULE}_config.sh
chmod +x /jffs/.koolshare/scripts/${MODULE}_status.sh
chmod +x /jffs/.koolshare/scripts/${MODULE}_uninstall.sh
chmod +x /jffs/.koolshare/init.d/S97${MODULE}.sh
sleep 1
dbus set ${MODULE}_version="${VERSION}"
#dbus set __event__onwanstart_npc=/jffs/.koolshare/scripts/${MODULE}_config.sh
#dbus set ${MODULE}_common_client_version=`/jffs/.koolshare/bin/${MODULE} --version`
dbus set ${MODULE}_common_client_version=${client_version}
dbus set softcenter_module_${MODULE}_install=1
dbus set softcenter_module_${MODULE}_name=${MODULE}
dbus set softcenter_module_${MODULE}_title="npc内网穿透"
dbus set softcenter_module_${MODULE}_description="npc内网穿透，☆夢幻煋涳☆ 制作, 官方QQ群:206610006"
dbus set softcenter_module_${MODULE}_version="${VERSION}"
en=`dbus get ${MODULE}_enable`
if [ "$en" == "1" ]; then
    /jffs/.koolshare/scripts/${MODULE}_config.sh
fi
echo "${MODULE} ${VERSION} install completed!"
