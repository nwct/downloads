#!/bin/sh
sh /jffs/.koolshare/scripts/npc_config.sh