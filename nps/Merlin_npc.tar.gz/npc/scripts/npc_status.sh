#! /bin/sh

export KSROOT=/jffs/.koolshare
source $KSROOT/scripts/base.sh

#判断http_response命令是否存在

result=`type http_response|grep "not found"`

if [ "${result}"x == ""x ];then
	common_echo="http_response"
else
	common_echo="echo"
fi


NAME="npc"
BIN=/jffs/.koolshare/bin/${NAME}
npc_pid=`ps | grep -w npc| grep -w server | grep -v grep | awk '{print $1}'`
npc_status=`ps | grep -w npc| grep -w server | grep -cv grep`
npc_common_client_version=`dbus get npc_common_client_version`

version=`${BIN}|grep -w version|awk -F "the version of client is |," '{print $2}'`
if [ "$version"x != ""x ];then
dbus set ${NAME}_common_client_version=$version
npc_common_client_version="$version"
fi

SIZE=`du /jffs/.koolshare/bin/npc|awk '{print $1}'`
npc_version_old=`dbus get npc_version`
npc_version_new=`wget -qO- -T 180 --no-check-certificate "https://raw.githubusercontent.com/nwct/downloads/master/nps/Merlin_npc_version"`

if [ "${npc_version_new}"x == ""x ];then
npc_version_new="$npc_version_old"
fi

if [ "${npc_version_old}"x = "${npc_version_new}"x ];then
	
	updateinfo=""
	
	else
	updateinfo="<a href=https://raw.githubusercontent.com/nwct/downloads/master/nps/Merlin_npc.tar.gz target=_blank><em><font color=red>【点击下载  插件版本：${npc_version_new}】</font></em></a><br>"
fi

if [ "${npc_status}" == "1" ];then
    ${common_echo} ${updateinfo}进程运行正常！版本：${npc_common_client_version} （PID：${npc_pid}）> /tmp/npc.log
else
    if [ ! -x "/jffs/.koolshare/bin/npc" -a $SIZE -gt 10 ];then
	
	INFO="正在下载程序，请稍后刷新！已下载：$SIZE KB"
	else
	INFO="进程未运行！"
	
	SIZE=`du $BIN|awk '{print $1}'`
	if [ -x /jffs/.koolshare/bin/npc -a $SIZE -gt 10 ];then
		sleep 1
	else
		rm -rf /jffs/.koolshare/bin/npc >/dev/null 2>&1
	fi

	fi
	

	${common_echo} ${updateinfo}\<em\>【警告】：${INFO}\<\/em\> 版本：${npc_common_client_version} > /tmp/npc.log
fi
${common_echo} XU6J03M6 >> /tmp/npc.log
sleep 2
rm -rf /tmp/npc.log
