#!/bin/sh
eval `dbus export npc_`
source /jffs/.koolshare/scripts/base.sh
MODULE=npc
/jffs/.koolshare/scripts/${MODULE}_config.sh stop
cd /
rm -f /jffs/.koolshare/bin/${MODULE}
rm -f /jffs/.koolshare/init.d/S97${MODULE}.sh
rm -f /jffs/.koolshare/res/${MODULE}_check.html
rm -f /jffs/.koolshare/res/${MODULE}-menu.js
rm -f /jffs/.koolshare/res/icon-${MODULE}.png
rm -f /jffs/.koolshare/scripts/${MODULE}_config.sh
rm -f /jffs/.koolshare/scripts/${MODULE}_status.sh
rm -f /jffs/.koolshare/scripts/${MODULE}_protect.sh
rm -f /jffs/.koolshare/webs/Module_${MODULE}.asp
rm -f /jffs/.koolshare/configs/${MODULE}.ini
rm -fr /tmp/npc*
values=`dbus list ${MODULE} | cut -d "=" -f 1`

for value in $values
do
dbus remove $value 
done
dbus remove __event__onwanstart_${MODULE}
dbus remove __event__onnatstart_${MODULE}
cru d ${MODULE}_monitor
rm -f /jffs/.koolshare/scripts/${MODULE}_uninstall.sh
