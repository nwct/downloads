#!/bin/sh

eval `dbus export npc_`
source /jffs/.koolshare/scripts/base.sh
NAME="npc"
BIN=/jffs/.koolshare/bin/${NAME}
PROTECT_FILE=/jffs/.koolshare/scripts/npc_protect.sh
INI_FILE=/jffs/.koolshare/configs/${NAME}.ini
PID_FILE=/var/run/${NAME}.pid
alias echo_date='echo $(date +%Y年%m月%d日\ %X):'
en=${npc_enable}

fun_ntp_sync(){
    ntp_server=`nvram get ntp_server0`
    start_time="`date +%Y%m%d`"
    ntpclient -h ${ntp_server} -i3 -l -s > /dev/null 2>&1
    if [ "${start_time}"x = "`date +%Y%m%d`"x ]; then
        ntpclient -h ntp1.aliyun.com -i3 -l -s > /dev/null 2>&1
    fi
}
fun_nat_start(){
    if [ "${npc_enable}"x = "1"x ];then
        echo_date 添加nat-start触发事件...
        dbus set __event__onnatstart_npc="/jffs/.koolshare/scripts/npc_config.sh"
    else
        echo_date 删除nat-start触发...
        dbus remove __event__onnatstart_npc
    fi
}

fun_version_select(){
	npc_common_client_version=`dbus get npc_common_client_version`
	npc_version_select=`dbus get npc_version_select`
	if [ "$npc_common_client_version"x != "$npc_version_select"x ];then
		killall ${NAME}
		rm -rf /jffs/.koolshare/bin/npc >/dev/null 2>&1
		if [ "$(uname -m|grep "mips")"x != ""x ];then
			cpu="mipsle"
		elif [ "$(uname -m|grep "arm")"x != ""x ];then
			cpu="arm"
		elif [ "$(uname -m|grep "aarch64")"x != ""x ];then
			cpu="arm64"
		else
			cpu="386"
		fi

		wget -q -O ${BIN} -T 180 --no-check-certificate "https://raw.githubusercontent.com/nwct/downloads/master/nps/linux-$cpu/$npc_version_select/npc"
		chmod 755 ${BIN}
	fi
	
}


fun_protect(){
    if [ "${npc_enable}"x = "1"x ];then
		npc_protect=`dbus get npc_protect`
		
		cat > ${PROTECT_FILE} <<EOF
#! /bin/sh
checknpc(){
PID=\`ps|grep -w "${BIN}"|grep -v grep|awk '{print \$1}'\`
if [ ! \$PID ];then




if [ ! -f "$BIN" ];then

if [ "\$(uname -m|grep "mips")"x != ""x ];then
cpu="mipsle"
elif [ "\$(uname -m|grep "arm")"x != ""x ];then
cpu="arm"
elif [ "\$(uname -m|grep "aarch64")"x != ""x ];then
cpu="arm64"
else
cpu="386"
fi

npc_version_select=\`dbus get npc_version_select\`

wget -q -O ${BIN} -T 181 --no-check-certificate "https://raw.githubusercontent.com/nwct/downloads/master/nps/linux-\$cpu/\$npc_version_select/npc"

chmod 755 ${BIN}

fi

SIZE=\`du $BIN|awk '{print \$1}'\`
if [ -x /jffs/.koolshare/bin/npc -a \$SIZE -gt 10 ];then
sleep 1
else
rm -rf /jffs/.koolshare/bin/npc >/dev/null 2>&1
fi

/bin/sh /jffs/.koolshare/scripts/npc_config.sh
fi
}

while true
do
checknpc
sleep 5
done

EOF
		chmod 755 ${PROTECT_FILE}
		
			if [ "${npc_protect}"x = "1"x ];then
				${PROTECT_FILE} &
				echo ""
			fi
    fi
}



onstart() {
fun_ntp_sync
killall ${NAME}_protect.sh || true >/dev/null 2>&1
killall ${NAME} || true >/dev/null 2>&1
version=`${BIN}|grep -w version|awk -F "the version of client is |," '{print $2}'`
if [ "$version"x != ""x ];then
dbus set ${NAME}_common_client_version=$version
fi
fun_version_select

cat > ${INI_FILE}<<-EOF
# npc custom configuration
${_npc_customize_conf}
EOF

npc_common_server_addr=`dbus get npc_common_server_addr`
npc_common_server_port=`dbus get npc_common_server_port`
npc_common_vkey=`dbus get npc_common_vkey`
npc_common_protocol=`dbus get npc_common_protocol`

if [ "$en" == "1" ]; then
echo -n "starting ${NAME}..."
export GOGC=40
start-stop-daemon -S -q -b -m -p ${PID_FILE} -x ${BIN} -- -server=${npc_common_server_addr}:${npc_common_server_port} -vkey=${npc_common_vkey} -type=${npc_common_protocol}
echo " done"
fun_nat_start
fun_protect
else
	stop
fi
}
stop() {
	echo -n "stop ${NAME}..."
	killall npc_protect.sh || true
	killall npc || true
	cru d npc_monitor
    fun_nat_start
	echo " done"
}

case $ACTION in
start)
    if [[ "$en" == "1" ]]; then
        logger "[软件中心]: 启动npc！"
        onstart
    fi
    ;;
stop)
	stop
	;;
*)
	onstart
	;;
esac
